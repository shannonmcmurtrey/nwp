class Assessment < ApplicationRecord
  belongs_to :individual
end
