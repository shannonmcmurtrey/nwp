class HouseholdMembersController < ApplicationController

	
end
