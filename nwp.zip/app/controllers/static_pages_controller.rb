class StaticPagesController < ApplicationController
  def home
  end

  def assistance
  end

  def reports
  end
end
