require 'test_helper'

class IndividualTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
