require 'test_helper'

class CohortTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
